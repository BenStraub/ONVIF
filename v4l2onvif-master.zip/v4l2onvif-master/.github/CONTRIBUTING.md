# Contributing

When contributing to this repository, please :
- be friendly, say Hello,
- prefer submission of a Pull Request than asking for new features,
- explain in your Pull Request what you modified and why.
