import Manager from './Manager';

new Manager();