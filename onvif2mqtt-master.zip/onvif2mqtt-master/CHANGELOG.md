## 1.0.3
- Manually create a PullPointSubscription for Hikvision cameras.

## 1.0.2
- Fixed event debouncer to support multiple ONVIF devices.

## 1.0.1
- Add `trace` log level to reflect all incoming messages through ONVIF.
- Fixed configuration not defaulting to port 1883 for MQTT.
- Fixed configuration skipping username / password values for MQTT.

## 1.0.0
- Initial release