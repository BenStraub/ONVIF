[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [DeviceEntity](_api_types_.deviceentity.md)

# Interface: DeviceEntity

Base class for physical entities like inputs and outputs.

## Hierarchy

* **DeviceEntity**
