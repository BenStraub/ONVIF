[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [CertificateInformationExtension](_api_types_.certificateinformationextension.md)

# Interface: CertificateInformationExtension

## Hierarchy

* **CertificateInformationExtension**
