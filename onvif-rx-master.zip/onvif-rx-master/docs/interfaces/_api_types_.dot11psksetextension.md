[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [Dot11PSKSetExtension](_api_types_.dot11psksetextension.md)

# Interface: Dot11PSKSetExtension

## Hierarchy

* **Dot11PSKSetExtension**
