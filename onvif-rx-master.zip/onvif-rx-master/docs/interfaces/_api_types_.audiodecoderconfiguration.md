[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [AudioDecoderConfiguration](_api_types_.audiodecoderconfiguration.md)

# Interface: AudioDecoderConfiguration

The Audio Decoder Configuration does not contain any that parameter to configure the
decoding .A decoder shall decode every data it receives (according to its capabilities).

## Hierarchy

* **AudioDecoderConfiguration**
