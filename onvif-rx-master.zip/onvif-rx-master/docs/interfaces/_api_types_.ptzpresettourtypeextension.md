[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PTZPresetTourTypeExtension](_api_types_.ptzpresettourtypeextension.md)

# Interface: PTZPresetTourTypeExtension

## Hierarchy

* **PTZPresetTourTypeExtension**
