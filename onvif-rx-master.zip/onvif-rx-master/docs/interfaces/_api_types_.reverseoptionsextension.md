[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ReverseOptionsExtension](_api_types_.reverseoptionsextension.md)

# Interface: ReverseOptionsExtension

## Hierarchy

* **ReverseOptionsExtension**
