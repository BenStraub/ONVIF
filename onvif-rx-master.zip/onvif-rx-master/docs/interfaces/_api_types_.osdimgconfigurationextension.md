[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [OSDImgConfigurationExtension](_api_types_.osdimgconfigurationextension.md)

# Interface: OSDImgConfigurationExtension

## Hierarchy

* **OSDImgConfigurationExtension**
