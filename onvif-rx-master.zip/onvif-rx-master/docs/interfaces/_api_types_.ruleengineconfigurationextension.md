[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [RuleEngineConfigurationExtension](_api_types_.ruleengineconfigurationextension.md)

# Interface: RuleEngineConfigurationExtension

## Hierarchy

* **RuleEngineConfigurationExtension**
