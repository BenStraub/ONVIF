[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [Dot1XConfigurationExtension](_api_types_.dot1xconfigurationextension.md)

# Interface: Dot1XConfigurationExtension

## Hierarchy

* **Dot1XConfigurationExtension**
