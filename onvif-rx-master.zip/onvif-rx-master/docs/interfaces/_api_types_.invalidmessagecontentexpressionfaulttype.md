[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [InvalidMessageContentExpressionFaultType](_api_types_.invalidmessagecontentexpressionfaulttype.md)

# Interface: InvalidMessageContentExpressionFaultType

## Hierarchy

* **InvalidMessageContentExpressionFaultType**
