[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [Polygon](_api_types_.polygon.md)

# Interface: Polygon

## Hierarchy

* **Polygon**

## Index

### Properties

* [Point](_api_types_.polygon.md#readonly-point)

## Properties

### `Readonly` Point

• **Point**: *[Vector](_api_types_.vector.md)*

*Defined in [api/types.ts:356](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L356)*
