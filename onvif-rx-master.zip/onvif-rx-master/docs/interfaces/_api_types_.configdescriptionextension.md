[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ConfigDescriptionExtension](_api_types_.configdescriptionextension.md)

# Interface: ConfigDescriptionExtension

## Hierarchy

* **ConfigDescriptionExtension**
