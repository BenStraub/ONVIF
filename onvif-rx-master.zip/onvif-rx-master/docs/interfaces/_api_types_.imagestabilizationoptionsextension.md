[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ImageStabilizationOptionsExtension](_api_types_.imagestabilizationoptionsextension.md)

# Interface: ImageStabilizationOptionsExtension

## Hierarchy

* **ImageStabilizationOptionsExtension**
