[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ArrayOfFileProgressExtension](_api_types_.arrayoffileprogressextension.md)

# Interface: ArrayOfFileProgressExtension

## Hierarchy

* **ArrayOfFileProgressExtension**
