[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [GeoOrientation](_api_types_.geoorientation.md)

# Interface: GeoOrientation

Rotation around the x axis.

## Hierarchy

* **GeoOrientation**
