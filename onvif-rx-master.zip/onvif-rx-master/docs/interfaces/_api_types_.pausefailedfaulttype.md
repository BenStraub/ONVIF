[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PauseFailedFaultType](_api_types_.pausefailedfaulttype.md)

# Interface: PauseFailedFaultType

## Hierarchy

* **PauseFailedFaultType**
