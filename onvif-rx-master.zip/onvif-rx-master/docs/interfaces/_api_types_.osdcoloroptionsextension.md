[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [OSDColorOptionsExtension](_api_types_.osdcoloroptionsextension.md)

# Interface: OSDColorOptionsExtension

## Hierarchy

* **OSDColorOptionsExtension**
