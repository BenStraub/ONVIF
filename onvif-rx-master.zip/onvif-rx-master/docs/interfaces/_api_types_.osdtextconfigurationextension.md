[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [OSDTextConfigurationExtension](_api_types_.osdtextconfigurationextension.md)

# Interface: OSDTextConfigurationExtension

## Hierarchy

* **OSDTextConfigurationExtension**
