[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [NetworkZeroConfigurationExtension2](_api_types_.networkzeroconfigurationextension2.md)

# Interface: NetworkZeroConfigurationExtension2

## Hierarchy

* **NetworkZeroConfigurationExtension2**
