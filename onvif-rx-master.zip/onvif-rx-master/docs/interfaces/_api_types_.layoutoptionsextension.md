[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [LayoutOptionsExtension](_api_types_.layoutoptionsextension.md)

# Interface: LayoutOptionsExtension

## Hierarchy

* **LayoutOptionsExtension**
