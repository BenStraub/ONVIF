[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [DynamicDNSInformationExtension](_api_types_.dynamicdnsinformationextension.md)

# Interface: DynamicDNSInformationExtension

## Hierarchy

* **DynamicDNSInformationExtension**
