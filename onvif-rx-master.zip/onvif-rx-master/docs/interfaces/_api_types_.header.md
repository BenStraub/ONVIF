[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [Header](_api_types_.header.md)

# Interface: Header

## Hierarchy

* **Header**
