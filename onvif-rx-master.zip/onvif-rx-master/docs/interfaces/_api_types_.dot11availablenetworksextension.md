[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [Dot11AvailableNetworksExtension](_api_types_.dot11availablenetworksextension.md)

# Interface: Dot11AvailableNetworksExtension

## Hierarchy

* **Dot11AvailableNetworksExtension**
