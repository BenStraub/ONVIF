[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PTZPresetTourStartingConditionExtension](_api_types_.ptzpresettourstartingconditionextension.md)

# Interface: PTZPresetTourStartingConditionExtension

## Hierarchy

* **PTZPresetTourStartingConditionExtension**
