[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PolylineArrayExtension](_api_types_.polylinearrayextension.md)

# Interface: PolylineArrayExtension

## Hierarchy

* **PolylineArrayExtension**
