[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [EapMethodExtension](_api_types_.eapmethodextension.md)

# Interface: EapMethodExtension

## Hierarchy

* **EapMethodExtension**
