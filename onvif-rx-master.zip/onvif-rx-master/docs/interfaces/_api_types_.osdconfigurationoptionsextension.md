[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [OSDConfigurationOptionsExtension](_api_types_.osdconfigurationoptionsextension.md)

# Interface: OSDConfigurationOptionsExtension

## Hierarchy

* **OSDConfigurationOptionsExtension**
