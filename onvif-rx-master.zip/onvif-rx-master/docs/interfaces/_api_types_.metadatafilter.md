[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [MetadataFilter](_api_types_.metadatafilter.md)

# Interface: MetadataFilter

## Hierarchy

* **MetadataFilter**

## Index

### Properties

* [MetadataStreamFilter](_api_types_.metadatafilter.md#readonly-metadatastreamfilter)

## Properties

### `Readonly` MetadataStreamFilter

• **MetadataStreamFilter**: *[XPathExpression](../modules/_api_types_.md#xpathexpression)*

*Defined in [api/types.ts:3658](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L3658)*
