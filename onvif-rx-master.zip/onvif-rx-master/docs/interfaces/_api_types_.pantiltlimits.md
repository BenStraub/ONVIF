[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PanTiltLimits](_api_types_.pantiltlimits.md)

# Interface: PanTiltLimits

A range of pan tilt limits.

## Hierarchy

* **PanTiltLimits**

## Index

### Properties

* [Range](_api_types_.pantiltlimits.md#readonly-range)

## Properties

### `Readonly` Range

• **Range**: *[Space2DDescription](_api_types_.space2ddescription.md)*

*Defined in [api/types.ts:2406](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L2406)*
