[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [AudioEncoderConfigurationOptions](_api_types_.audioencoderconfigurationoptions.md)

# Interface: AudioEncoderConfigurationOptions

list of supported AudioEncoderConfigurations

## Hierarchy

* **AudioEncoderConfigurationOptions**

## Index

### Properties

* [Options](_api_types_.audioencoderconfigurationoptions.md#optional-readonly-options)

## Properties

### `Optional` `Readonly` Options

• **Options**? : *[AudioEncoderConfigurationOption](_api_types_.audioencoderconfigurationoption.md)*

*Defined in [api/types.ts:912](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L912)*
