[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [IntItems](_api_types_.intitems.md)

# Interface: IntItems

List of values.

## Hierarchy

* **IntItems**

## Index

### Properties

* [Items](_api_types_.intitems.md#optional-readonly-items)

## Properties

### `Optional` `Readonly` Items

• **Items**? : *undefined | number*

*Defined in [api/types.ts:497](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L497)*
