[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [InvalidTopicExpressionFaultType](_api_types_.invalidtopicexpressionfaulttype.md)

# Interface: InvalidTopicExpressionFaultType

## Hierarchy

* **InvalidTopicExpressionFaultType**
