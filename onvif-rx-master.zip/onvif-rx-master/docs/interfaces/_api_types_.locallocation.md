[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [LocalLocation](_api_types_.locallocation.md)

# Interface: LocalLocation

East west location as angle.

## Hierarchy

* **LocalLocation**
