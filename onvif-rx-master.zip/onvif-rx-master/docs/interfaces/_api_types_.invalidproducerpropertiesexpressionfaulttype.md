[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [InvalidProducerPropertiesExpressionFaultType](_api_types_.invalidproducerpropertiesexpressionfaulttype.md)

# Interface: InvalidProducerPropertiesExpressionFaultType

## Hierarchy

* **InvalidProducerPropertiesExpressionFaultType**
