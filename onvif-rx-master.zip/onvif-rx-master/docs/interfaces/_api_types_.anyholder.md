[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [AnyHolder](_api_types_.anyholder.md)

# Interface: AnyHolder

## Hierarchy

* **AnyHolder**
