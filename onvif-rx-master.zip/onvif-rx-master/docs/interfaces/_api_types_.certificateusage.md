[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [CertificateUsage](_api_types_.certificateusage.md)

# Interface: CertificateUsage

## Hierarchy

* **CertificateUsage**
