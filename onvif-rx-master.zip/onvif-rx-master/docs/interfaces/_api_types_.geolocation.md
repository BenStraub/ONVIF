[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [GeoLocation](_api_types_.geolocation.md)

# Interface: GeoLocation

East west location as angle.

## Hierarchy

* **GeoLocation**
