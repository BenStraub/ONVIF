[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [CertificateGenerationParametersExtension](_api_types_.certificategenerationparametersextension.md)

# Interface: CertificateGenerationParametersExtension

## Hierarchy

* **CertificateGenerationParametersExtension**
