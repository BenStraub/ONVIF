[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [EventFilter](_api_types_.eventfilter.md)

# Interface: EventFilter

## Hierarchy

* **EventFilter**
