[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [AnalyticsEngineConfigurationExtension](_api_types_.analyticsengineconfigurationextension.md)

# Interface: AnalyticsEngineConfigurationExtension

## Hierarchy

* **AnalyticsEngineConfigurationExtension**
