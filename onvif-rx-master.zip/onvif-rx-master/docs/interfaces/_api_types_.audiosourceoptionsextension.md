[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [AudioSourceOptionsExtension](_api_types_.audiosourceoptionsextension.md)

# Interface: AudioSourceOptionsExtension

## Hierarchy

* **AudioSourceOptionsExtension**
