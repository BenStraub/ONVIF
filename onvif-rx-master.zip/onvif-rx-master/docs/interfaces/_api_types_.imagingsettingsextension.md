[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ImagingSettingsExtension](_api_types_.imagingsettingsextension.md)

# Interface: ImagingSettingsExtension

## Hierarchy

* **ImagingSettingsExtension**
