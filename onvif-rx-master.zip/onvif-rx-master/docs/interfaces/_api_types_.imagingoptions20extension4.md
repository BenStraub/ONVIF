[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ImagingOptions20Extension4](_api_types_.imagingoptions20extension4.md)

# Interface: ImagingOptions20Extension4

## Hierarchy

* **ImagingOptions20Extension4**
