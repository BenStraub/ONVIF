[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ImagingStatus](_api_types_.imagingstatus.md)

# Interface: ImagingStatus

## Hierarchy

* **ImagingStatus**

## Index

### Properties

* [FocusStatus](_api_types_.imagingstatus.md#readonly-focusstatus)

## Properties

### `Readonly` FocusStatus

• **FocusStatus**: *[FocusStatus](_api_types_.focusstatus.md)*

*Defined in [api/types.ts:2616](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L2616)*
