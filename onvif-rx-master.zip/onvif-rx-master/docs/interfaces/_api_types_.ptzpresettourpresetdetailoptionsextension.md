[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PTZPresetTourPresetDetailOptionsExtension](_api_types_.ptzpresettourpresetdetailoptionsextension.md)

# Interface: PTZPresetTourPresetDetailOptionsExtension

## Hierarchy

* **PTZPresetTourPresetDetailOptionsExtension**
