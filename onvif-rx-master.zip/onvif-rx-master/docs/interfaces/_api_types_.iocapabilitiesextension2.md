[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [IOCapabilitiesExtension2](_api_types_.iocapabilitiesextension2.md)

# Interface: IOCapabilitiesExtension2

## Hierarchy

* **IOCapabilitiesExtension2**
