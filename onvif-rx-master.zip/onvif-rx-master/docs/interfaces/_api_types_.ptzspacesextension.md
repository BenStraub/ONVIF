[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PTZSpacesExtension](_api_types_.ptzspacesextension.md)

# Interface: PTZSpacesExtension

## Hierarchy

* **PTZSpacesExtension**
