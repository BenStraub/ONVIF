[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PTZPresetTourStatusExtension](_api_types_.ptzpresettourstatusextension.md)

# Interface: PTZPresetTourStatusExtension

## Hierarchy

* **PTZPresetTourStatusExtension**
