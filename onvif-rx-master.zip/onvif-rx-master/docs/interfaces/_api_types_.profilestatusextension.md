[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ProfileStatusExtension](_api_types_.profilestatusextension.md)

# Interface: ProfileStatusExtension

## Hierarchy

* **ProfileStatusExtension**
