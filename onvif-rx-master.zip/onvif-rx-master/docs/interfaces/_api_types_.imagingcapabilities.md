[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ImagingCapabilities](_api_types_.imagingcapabilities.md)

# Interface: ImagingCapabilities

Imaging service URI.

## Hierarchy

* **ImagingCapabilities**

## Index

### Properties

* [XAddr](_api_types_.imagingcapabilities.md#readonly-xaddr)

## Properties

### `Readonly` XAddr

• **XAddr**: *string*

*Defined in [api/types.ts:1858](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L1858)*
