[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [IrCutFilterAutoAdjustmentOptionsExtension](_api_types_.ircutfilterautoadjustmentoptionsextension.md)

# Interface: IrCutFilterAutoAdjustmentOptionsExtension

## Hierarchy

* **IrCutFilterAutoAdjustmentOptionsExtension**
