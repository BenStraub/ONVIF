[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [FocusConfiguration20Extension](_api_types_.focusconfiguration20extension.md)

# Interface: FocusConfiguration20Extension

## Hierarchy

* **FocusConfiguration20Extension**
