[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [AudioOutput](_api_types_.audiooutput.md)

# Interface: AudioOutput

Representation of a physical audio outputs.

## Hierarchy

* **AudioOutput**
