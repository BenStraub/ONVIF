[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [IntRectangle](_api_types_.intrectangle.md)

# Interface: IntRectangle

Rectangle defined by lower left corner position and size. Units are pixel.

## Hierarchy

* **IntRectangle**
