[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PolylineArrayConfiguration](_api_types_.polylinearrayconfiguration.md)

# Interface: PolylineArrayConfiguration

Contains PolylineArray configuration data

## Hierarchy

* **PolylineArrayConfiguration**

## Index

### Properties

* [PolylineArray](_api_types_.polylinearrayconfiguration.md#readonly-polylinearray)

## Properties

### `Readonly` PolylineArray

• **PolylineArray**: *[PolylineArray](_api_types_.polylinearray.md)*

*Defined in [api/types.ts:3473](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L3473)*
