[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [Envelope](_api_types_.envelope.md)

# Interface: Envelope

## Hierarchy

* **Envelope**
