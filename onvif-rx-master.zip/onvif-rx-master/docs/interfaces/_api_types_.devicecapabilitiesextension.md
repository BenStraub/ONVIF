[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [DeviceCapabilitiesExtension](_api_types_.devicecapabilitiesextension.md)

# Interface: DeviceCapabilitiesExtension

## Hierarchy

* **DeviceCapabilitiesExtension**
