[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PTZNodeExtension2](_api_types_.ptznodeextension2.md)

# Interface: PTZNodeExtension2

## Hierarchy

* **PTZNodeExtension2**
