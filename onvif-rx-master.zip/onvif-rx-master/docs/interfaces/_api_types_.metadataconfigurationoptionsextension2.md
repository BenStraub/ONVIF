[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [MetadataConfigurationOptionsExtension2](_api_types_.metadataconfigurationoptionsextension2.md)

# Interface: MetadataConfigurationOptionsExtension2

## Hierarchy

* **MetadataConfigurationOptionsExtension2**
