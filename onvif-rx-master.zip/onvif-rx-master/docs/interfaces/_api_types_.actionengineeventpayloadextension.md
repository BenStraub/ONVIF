[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ActionEngineEventPayloadExtension](_api_types_.actionengineeventpayloadextension.md)

# Interface: ActionEngineEventPayloadExtension

## Hierarchy

* **ActionEngineEventPayloadExtension**
