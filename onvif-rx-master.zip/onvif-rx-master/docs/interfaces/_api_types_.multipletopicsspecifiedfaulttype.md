[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [MultipleTopicsSpecifiedFaultType](_api_types_.multipletopicsspecifiedfaulttype.md)

# Interface: MultipleTopicsSpecifiedFaultType

## Hierarchy

* **MultipleTopicsSpecifiedFaultType**
