[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [AnalyticsDeviceEngineConfigurationExtension](_api_types_.analyticsdeviceengineconfigurationextension.md)

# Interface: AnalyticsDeviceEngineConfigurationExtension

## Hierarchy

* **AnalyticsDeviceEngineConfigurationExtension**
