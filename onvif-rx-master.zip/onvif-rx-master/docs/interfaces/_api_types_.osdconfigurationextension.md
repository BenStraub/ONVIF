[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [OSDConfigurationExtension](_api_types_.osdconfigurationextension.md)

# Interface: OSDConfigurationExtension

## Hierarchy

* **OSDConfigurationExtension**
