[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [Dot3Configuration](_api_types_.dot3configuration.md)

# Interface: Dot3Configuration

## Hierarchy

* **Dot3Configuration**
