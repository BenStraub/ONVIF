[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [detail](_api_types_.detail.md)

# Interface: detail

## Hierarchy

* **detail**
