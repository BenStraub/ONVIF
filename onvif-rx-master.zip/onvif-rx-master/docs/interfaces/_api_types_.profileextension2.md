[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ProfileExtension2](_api_types_.profileextension2.md)

# Interface: ProfileExtension2

## Hierarchy

* **ProfileExtension2**
