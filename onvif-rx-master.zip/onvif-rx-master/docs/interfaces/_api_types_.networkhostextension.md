[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [NetworkHostExtension](_api_types_.networkhostextension.md)

# Interface: NetworkHostExtension

## Hierarchy

* **NetworkHostExtension**
