[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PTControlDirectionOptionsExtension](_api_types_.ptcontroldirectionoptionsextension.md)

# Interface: PTControlDirectionOptionsExtension

## Hierarchy

* **PTControlDirectionOptionsExtension**
