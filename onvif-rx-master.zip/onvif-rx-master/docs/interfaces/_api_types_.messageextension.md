[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [MessageExtension](_api_types_.messageextension.md)

# Interface: MessageExtension

## Hierarchy

* **MessageExtension**
