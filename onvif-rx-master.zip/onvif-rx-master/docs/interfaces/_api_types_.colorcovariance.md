[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ColorCovariance](_api_types_.colorcovariance.md)

# Interface: ColorCovariance

Acceptable values are the same as in tt:Color.

## Hierarchy

* **ColorCovariance**
