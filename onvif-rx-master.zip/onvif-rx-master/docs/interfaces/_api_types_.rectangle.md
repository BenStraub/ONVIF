[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [Rectangle](_api_types_.rectangle.md)

# Interface: Rectangle

## Hierarchy

* **Rectangle**
