[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [LensOffset](_api_types_.lensoffset.md)

# Interface: LensOffset

Optional horizontal offset of the lens center in normalized coordinates.

## Hierarchy

* **LensOffset**
