[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [RealTimeStreamingCapabilitiesExtension](_api_types_.realtimestreamingcapabilitiesextension.md)

# Interface: RealTimeStreamingCapabilitiesExtension

## Hierarchy

* **RealTimeStreamingCapabilitiesExtension**
