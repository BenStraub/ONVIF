[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PTZConfigurationOptions2](_api_types_.ptzconfigurationoptions2.md)

# Interface: PTZConfigurationOptions2

## Hierarchy

* **PTZConfigurationOptions2**
