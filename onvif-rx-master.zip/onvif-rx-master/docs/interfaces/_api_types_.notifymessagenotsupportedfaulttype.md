[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [NotifyMessageNotSupportedFaultType](_api_types_.notifymessagenotsupportedfaulttype.md)

# Interface: NotifyMessageNotSupportedFaultType

## Hierarchy

* **NotifyMessageNotSupportedFaultType**
