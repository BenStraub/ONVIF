[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [DefoggingExtension](_api_types_.defoggingextension.md)

# Interface: DefoggingExtension

## Hierarchy

* **DefoggingExtension**
