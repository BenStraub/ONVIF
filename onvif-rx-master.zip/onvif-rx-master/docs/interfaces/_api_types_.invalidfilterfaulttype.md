[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [InvalidFilterFaultType](_api_types_.invalidfilterfaulttype.md)

# Interface: InvalidFilterFaultType

## Hierarchy

* **InvalidFilterFaultType**

## Index

### Properties

* [UnknownFilter](_api_types_.invalidfilterfaulttype.md#readonly-unknownfilter)

## Properties

### `Readonly` UnknownFilter

• **UnknownFilter**: *any*

*Defined in [api/types.ts:160](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L160)*
