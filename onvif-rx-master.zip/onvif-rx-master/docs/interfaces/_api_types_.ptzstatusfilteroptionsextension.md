[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PTZStatusFilterOptionsExtension](_api_types_.ptzstatusfilteroptionsextension.md)

# Interface: PTZStatusFilterOptionsExtension

## Hierarchy

* **PTZStatusFilterOptionsExtension**
