[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [IrCutFilterAutoAdjustmentExtension](_api_types_.ircutfilterautoadjustmentextension.md)

# Interface: IrCutFilterAutoAdjustmentExtension

## Hierarchy

* **IrCutFilterAutoAdjustmentExtension**
