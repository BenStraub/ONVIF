[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [MetadataConfigurationExtension](_api_types_.metadataconfigurationextension.md)

# Interface: MetadataConfigurationExtension

## Hierarchy

* **MetadataConfigurationExtension**
