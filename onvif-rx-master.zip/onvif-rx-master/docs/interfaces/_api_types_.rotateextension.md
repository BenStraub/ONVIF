[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [RotateExtension](_api_types_.rotateextension.md)

# Interface: RotateExtension

## Hierarchy

* **RotateExtension**
