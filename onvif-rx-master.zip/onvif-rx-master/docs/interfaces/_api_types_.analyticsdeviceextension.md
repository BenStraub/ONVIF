[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [AnalyticsDeviceExtension](_api_types_.analyticsdeviceextension.md)

# Interface: AnalyticsDeviceExtension

## Hierarchy

* **AnalyticsDeviceExtension**
