[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PTControlDirectionExtension](_api_types_.ptcontroldirectionextension.md)

# Interface: PTControlDirectionExtension

## Hierarchy

* **PTControlDirectionExtension**
