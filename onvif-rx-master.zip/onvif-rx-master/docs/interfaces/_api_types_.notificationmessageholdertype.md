[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [NotificationMessageHolderType](_api_types_.notificationmessageholdertype.md)

# Interface: NotificationMessageHolderType

## Hierarchy

* **NotificationMessageHolderType**

## Index

### Properties

* [Message](_api_types_.notificationmessageholdertype.md#readonly-message)

## Properties

### `Readonly` Message

• **Message**: *any*

*Defined in [api/types.ts:147](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L147)*
