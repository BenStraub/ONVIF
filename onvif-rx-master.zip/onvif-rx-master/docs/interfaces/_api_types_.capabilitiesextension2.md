[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [CapabilitiesExtension2](_api_types_.capabilitiesextension2.md)

# Interface: CapabilitiesExtension2

## Hierarchy

* **CapabilitiesExtension2**
