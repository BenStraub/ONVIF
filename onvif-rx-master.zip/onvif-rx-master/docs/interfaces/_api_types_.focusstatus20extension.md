[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [FocusStatus20Extension](_api_types_.focusstatus20extension.md)

# Interface: FocusStatus20Extension

## Hierarchy

* **FocusStatus20Extension**
