[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [RecordingJobStateTracks](_api_types_.recordingjobstatetracks.md)

# Interface: RecordingJobStateTracks

## Hierarchy

* **RecordingJobStateTracks**

## Index

### Properties

* [Track](_api_types_.recordingjobstatetracks.md#optional-readonly-track)

## Properties

### `Optional` `Readonly` Track

• **Track**? : *[RecordingJobStateTrack](_api_types_.recordingjobstatetrack.md)*

*Defined in [api/types.ts:3939](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L3939)*
