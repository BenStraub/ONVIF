[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ResumeFailedFaultType](_api_types_.resumefailedfaulttype.md)

# Interface: ResumeFailedFaultType

## Hierarchy

* **ResumeFailedFaultType**
