[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [Polyline](_api_types_.polyline.md)

# Interface: Polyline

## Hierarchy

* **Polyline**

## Index

### Properties

* [Point](_api_types_.polyline.md#readonly-point)

## Properties

### `Readonly` Point

• **Point**: *[Vector](_api_types_.vector.md)*

*Defined in [api/types.ts:3364](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L3364)*
