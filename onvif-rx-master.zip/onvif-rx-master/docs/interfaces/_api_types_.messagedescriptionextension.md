[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [MessageDescriptionExtension](_api_types_.messagedescriptionextension.md)

# Interface: MessageDescriptionExtension

## Hierarchy

* **MessageDescriptionExtension**
