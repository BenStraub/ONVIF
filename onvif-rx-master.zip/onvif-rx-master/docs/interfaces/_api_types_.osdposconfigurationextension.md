[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [OSDPosConfigurationExtension](_api_types_.osdposconfigurationextension.md)

# Interface: OSDPosConfigurationExtension

## Hierarchy

* **OSDPosConfigurationExtension**
