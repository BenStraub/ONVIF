[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ImageStabilizationExtension](_api_types_.imagestabilizationextension.md)

# Interface: ImageStabilizationExtension

## Hierarchy

* **ImageStabilizationExtension**
