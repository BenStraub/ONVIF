[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ItemListExtension](_api_types_.itemlistextension.md)

# Interface: ItemListExtension

## Hierarchy

* **ItemListExtension**
