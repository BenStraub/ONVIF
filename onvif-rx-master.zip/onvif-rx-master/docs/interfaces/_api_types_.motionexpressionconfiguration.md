[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [MotionExpressionConfiguration](_api_types_.motionexpressionconfiguration.md)

# Interface: MotionExpressionConfiguration

Contains Rule MotionExpression configuration

## Hierarchy

* **MotionExpressionConfiguration**

## Index

### Properties

* [MotionExpression](_api_types_.motionexpressionconfiguration.md#readonly-motionexpression)

## Properties

### `Readonly` MotionExpression

• **MotionExpression**: *[MotionExpression](_api_types_.motionexpression.md)*

*Defined in [api/types.ts:3487](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L3487)*
