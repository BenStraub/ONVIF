[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [HostnameInformationExtension](_api_types_.hostnameinformationextension.md)

# Interface: HostnameInformationExtension

## Hierarchy

* **HostnameInformationExtension**
