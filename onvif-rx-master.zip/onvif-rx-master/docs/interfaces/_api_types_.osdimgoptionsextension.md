[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [OSDImgOptionsExtension](_api_types_.osdimgoptionsextension.md)

# Interface: OSDImgOptionsExtension

## Hierarchy

* **OSDImgOptionsExtension**
