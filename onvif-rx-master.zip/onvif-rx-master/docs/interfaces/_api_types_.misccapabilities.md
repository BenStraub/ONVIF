[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [MiscCapabilities](_api_types_.misccapabilities.md)

# Interface: MiscCapabilities

Lists of commands supported by SendAuxiliaryCommand.

## Hierarchy

* **MiscCapabilities**
