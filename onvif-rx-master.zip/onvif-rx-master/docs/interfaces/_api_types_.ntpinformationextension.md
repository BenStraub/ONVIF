[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [NTPInformationExtension](_api_types_.ntpinformationextension.md)

# Interface: NTPInformationExtension

## Hierarchy

* **NTPInformationExtension**
