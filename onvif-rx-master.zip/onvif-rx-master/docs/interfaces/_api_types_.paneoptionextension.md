[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PaneOptionExtension](_api_types_.paneoptionextension.md)

# Interface: PaneOptionExtension

## Hierarchy

* **PaneOptionExtension**
