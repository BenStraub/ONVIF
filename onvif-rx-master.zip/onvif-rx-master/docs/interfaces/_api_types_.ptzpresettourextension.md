[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PTZPresetTourExtension](_api_types_.ptzpresettourextension.md)

# Interface: PTZPresetTourExtension

## Hierarchy

* **PTZPresetTourExtension**
