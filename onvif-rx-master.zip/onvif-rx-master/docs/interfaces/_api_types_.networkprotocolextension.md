[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [NetworkProtocolExtension](_api_types_.networkprotocolextension.md)

# Interface: NetworkProtocolExtension

## Hierarchy

* **NetworkProtocolExtension**
