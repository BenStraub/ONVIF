[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PTZConfigurationExtension2](_api_types_.ptzconfigurationextension2.md)

# Interface: PTZConfigurationExtension2

## Hierarchy

* **PTZConfigurationExtension2**
