[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [DigitalInput](_api_types_.digitalinput.md)

# Interface: DigitalInput

Indicate the Digital IdleState status.

## Hierarchy

* **DigitalInput**
