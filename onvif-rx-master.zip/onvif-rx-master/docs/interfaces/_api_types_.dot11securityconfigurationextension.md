[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [Dot11SecurityConfigurationExtension](_api_types_.dot11securityconfigurationextension.md)

# Interface: Dot11SecurityConfigurationExtension

## Hierarchy

* **Dot11SecurityConfigurationExtension**
