[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [AudioDecoderConfigurationOptionsExtension](_api_types_.audiodecoderconfigurationoptionsextension.md)

# Interface: AudioDecoderConfigurationOptionsExtension

## Hierarchy

* **AudioDecoderConfigurationOptionsExtension**
