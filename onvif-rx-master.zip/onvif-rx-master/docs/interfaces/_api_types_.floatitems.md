[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [FloatItems](_api_types_.floatitems.md)

# Interface: FloatItems

## Hierarchy

* **FloatItems**

## Index

### Properties

* [Items](_api_types_.floatitems.md#optional-readonly-items)

## Properties

### `Optional` `Readonly` Items

• **Items**? : *undefined | number*

*Defined in [api/types.ts:504](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L504)*
