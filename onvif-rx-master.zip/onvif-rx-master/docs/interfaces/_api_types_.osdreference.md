[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [OSDReference](_api_types_.osdreference.md)

# Interface: OSDReference

## Hierarchy

* **OSDReference**
