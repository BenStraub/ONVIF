[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [Body](_api_types_.body.md)

# Interface: Body

Prose in the spec does not specify that attributes are allowed on the Body element

## Hierarchy

* **Body**
