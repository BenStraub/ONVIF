[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [RecordingJobSourceExtension](_api_types_.recordingjobsourceextension.md)

# Interface: RecordingJobSourceExtension

## Hierarchy

* **RecordingJobSourceExtension**
