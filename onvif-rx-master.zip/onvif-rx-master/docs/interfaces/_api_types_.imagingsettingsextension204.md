[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ImagingSettingsExtension204](_api_types_.imagingsettingsextension204.md)

# Interface: ImagingSettingsExtension204

## Hierarchy

* **ImagingSettingsExtension204**
