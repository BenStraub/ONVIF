[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PTZPresetTourSpotExtension](_api_types_.ptzpresettourspotextension.md)

# Interface: PTZPresetTourSpotExtension

## Hierarchy

* **PTZPresetTourSpotExtension**
