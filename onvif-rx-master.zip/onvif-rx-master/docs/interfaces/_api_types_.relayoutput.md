[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [RelayOutput](_api_types_.relayoutput.md)

# Interface: RelayOutput

## Hierarchy

* **RelayOutput**

## Index

### Properties

* [Properties](_api_types_.relayoutput.md#readonly-properties)

## Properties

### `Readonly` Properties

• **Properties**: *[RelayOutputSettings](_api_types_.relayoutputsettings.md)*

*Defined in [api/types.ts:2220](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L2220)*
