[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [QueryExpressionType](_api_types_.queryexpressiontype.md)

# Interface: QueryExpressionType

## Hierarchy

* **QueryExpressionType**
