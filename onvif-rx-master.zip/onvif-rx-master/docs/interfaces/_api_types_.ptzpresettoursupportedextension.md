[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PTZPresetTourSupportedExtension](_api_types_.ptzpresettoursupportedextension.md)

# Interface: PTZPresetTourSupportedExtension

## Hierarchy

* **PTZPresetTourSupportedExtension**
