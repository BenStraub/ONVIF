[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PTZPresetTourStartingConditionOptionsExtension](_api_types_.ptzpresettourstartingconditionoptionsextension.md)

# Interface: PTZPresetTourStartingConditionOptionsExtension

## Hierarchy

* **PTZPresetTourStartingConditionOptionsExtension**
