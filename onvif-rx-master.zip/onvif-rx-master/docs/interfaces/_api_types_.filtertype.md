[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [FilterType](_api_types_.filtertype.md)

# Interface: FilterType

## Hierarchy

* **FilterType**
