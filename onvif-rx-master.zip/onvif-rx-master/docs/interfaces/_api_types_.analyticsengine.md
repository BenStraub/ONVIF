[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [AnalyticsEngine](_api_types_.analyticsengine.md)

# Interface: AnalyticsEngine

## Hierarchy

* **AnalyticsEngine**

## Index

### Properties

* [AnalyticsEngineConfiguration](_api_types_.analyticsengine.md#readonly-analyticsengineconfiguration)

## Properties

### `Readonly` AnalyticsEngineConfiguration

• **AnalyticsEngineConfiguration**: *[AnalyticsDeviceEngineConfiguration](_api_types_.analyticsdeviceengineconfiguration.md)*

*Defined in [api/types.ts:3973](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L3973)*
