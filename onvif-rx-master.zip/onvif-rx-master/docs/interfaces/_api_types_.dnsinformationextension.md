[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [DNSInformationExtension](_api_types_.dnsinformationextension.md)

# Interface: DNSInformationExtension

## Hierarchy

* **DNSInformationExtension**
