[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [AttachmentData](_api_types_.attachmentdata.md)

# Interface: AttachmentData

## Hierarchy

* **AttachmentData**
