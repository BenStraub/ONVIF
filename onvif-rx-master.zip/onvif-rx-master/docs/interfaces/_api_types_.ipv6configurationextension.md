[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [IPv6ConfigurationExtension](_api_types_.ipv6configurationextension.md)

# Interface: IPv6ConfigurationExtension

## Hierarchy

* **IPv6ConfigurationExtension**
