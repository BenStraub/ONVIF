[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [RecordingJobStateInformationExtension](_api_types_.recordingjobstateinformationextension.md)

# Interface: RecordingJobStateInformationExtension

## Hierarchy

* **RecordingJobStateInformationExtension**
