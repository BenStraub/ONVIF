[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [NetworkInterfaceSetConfigurationExtension2](_api_types_.networkinterfacesetconfigurationextension2.md)

# Interface: NetworkInterfaceSetConfigurationExtension2

## Hierarchy

* **NetworkInterfaceSetConfigurationExtension2**
