[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [IPAddressFilterExtension](_api_types_.ipaddressfilterextension.md)

# Interface: IPAddressFilterExtension

## Hierarchy

* **IPAddressFilterExtension**
