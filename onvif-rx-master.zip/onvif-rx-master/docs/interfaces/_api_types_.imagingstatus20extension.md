[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ImagingStatus20Extension](_api_types_.imagingstatus20extension.md)

# Interface: ImagingStatus20Extension

## Hierarchy

* **ImagingStatus20Extension**
