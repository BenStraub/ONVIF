[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [LocalOrientation](_api_types_.localorientation.md)

# Interface: LocalOrientation

Rotation around the y axis.

## Hierarchy

* **LocalOrientation**
