[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [NetworkInterfaceExtension2](_api_types_.networkinterfaceextension2.md)

# Interface: NetworkInterfaceExtension2

## Hierarchy

* **NetworkInterfaceExtension2**
