[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [GenericEapPwdConfigurationExtension](_api_types_.genericeappwdconfigurationextension.md)

# Interface: GenericEapPwdConfigurationExtension

## Hierarchy

* **GenericEapPwdConfigurationExtension**
