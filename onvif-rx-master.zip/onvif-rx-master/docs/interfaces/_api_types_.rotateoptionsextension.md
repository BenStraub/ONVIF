[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [RotateOptionsExtension](_api_types_.rotateoptionsextension.md)

# Interface: RotateOptionsExtension

## Hierarchy

* **RotateOptionsExtension**
