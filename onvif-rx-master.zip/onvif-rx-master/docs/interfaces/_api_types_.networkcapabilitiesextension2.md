[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [NetworkCapabilitiesExtension2](_api_types_.networkcapabilitiesextension2.md)

# Interface: NetworkCapabilitiesExtension2

## Hierarchy

* **NetworkCapabilitiesExtension2**
