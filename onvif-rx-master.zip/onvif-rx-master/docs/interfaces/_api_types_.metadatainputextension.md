[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [MetadataInputExtension](_api_types_.metadatainputextension.md)

# Interface: MetadataInputExtension

## Hierarchy

* **MetadataInputExtension**
