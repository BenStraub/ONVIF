[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ReplayCapabilities](_api_types_.replaycapabilities.md)

# Interface: ReplayCapabilities

The address of the replay service.

## Hierarchy

* **ReplayCapabilities**

## Index

### Properties

* [XAddr](_api_types_.replaycapabilities.md#readonly-xaddr)

## Properties

### `Readonly` XAddr

• **XAddr**: *string*

*Defined in [api/types.ts:1912](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L1912)*
