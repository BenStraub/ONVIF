[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [RecordingJobConfigurationExtension](_api_types_.recordingjobconfigurationextension.md)

# Interface: RecordingJobConfigurationExtension

## Hierarchy

* **RecordingJobConfigurationExtension**
