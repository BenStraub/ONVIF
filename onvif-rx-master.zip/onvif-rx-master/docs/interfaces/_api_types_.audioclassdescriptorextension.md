[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [AudioClassDescriptorExtension](_api_types_.audioclassdescriptorextension.md)

# Interface: AudioClassDescriptorExtension

## Hierarchy

* **AudioClassDescriptorExtension**
