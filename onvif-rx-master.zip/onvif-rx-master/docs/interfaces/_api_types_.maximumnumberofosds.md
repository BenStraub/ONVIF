[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [MaximumNumberOfOSDs](_api_types_.maximumnumberofosds.md)

# Interface: MaximumNumberOfOSDs

## Hierarchy

* **MaximumNumberOfOSDs**
