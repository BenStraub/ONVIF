[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [MediaCapabilitiesExtension](_api_types_.mediacapabilitiesextension.md)

# Interface: MediaCapabilitiesExtension

## Hierarchy

* **MediaCapabilitiesExtension**

## Index

### Properties

* [ProfileCapabilities](_api_types_.mediacapabilitiesextension.md#readonly-profilecapabilities)

## Properties

### `Readonly` ProfileCapabilities

• **ProfileCapabilities**: *[ProfileCapabilities](_api_types_.profilecapabilities.md)*

*Defined in [api/types.ts:1732](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L1732)*
