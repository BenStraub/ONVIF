[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [AnalyticsEngineInputInfoExtension](_api_types_.analyticsengineinputinfoextension.md)

# Interface: AnalyticsEngineInputInfoExtension

## Hierarchy

* **AnalyticsEngineInputInfoExtension**
