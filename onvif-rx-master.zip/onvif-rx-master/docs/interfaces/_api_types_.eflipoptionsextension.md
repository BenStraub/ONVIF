[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [EFlipOptionsExtension](_api_types_.eflipoptionsextension.md)

# Interface: EFlipOptionsExtension

## Hierarchy

* **EFlipOptionsExtension**
