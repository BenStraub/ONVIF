[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [Enabled](_api_types_.enabled.md)

# Enumeration: Enabled

## Index

### Enumeration members

* [DISABLED](_api_types_.enabled.md#disabled)
* [ENABLED](_api_types_.enabled.md#enabled)

## Enumeration members

###  DISABLED

• **DISABLED**: = "DISABLED"

*Defined in [api/types.ts:5469](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5469)*

___

###  ENABLED

• **ENABLED**: = "ENABLED"

*Defined in [api/types.ts:5465](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5465)*
