[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [DynamicDNSType](_api_types_.dynamicdnstype.md)

# Enumeration: DynamicDNSType

## Index

### Enumeration members

* [ClientUpdates](_api_types_.dynamicdnstype.md#clientupdates)
* [NoUpdate](_api_types_.dynamicdnstype.md#noupdate)
* [ServerUpdates](_api_types_.dynamicdnstype.md#serverupdates)

## Enumeration members

###  ClientUpdates

• **ClientUpdates**: = "ClientUpdates"

*Defined in [api/types.ts:4971](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4971)*

___

###  NoUpdate

• **NoUpdate**: = "NoUpdate"

*Defined in [api/types.ts:4967](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4967)*

___

###  ServerUpdates

• **ServerUpdates**: = "ServerUpdates"

*Defined in [api/types.ts:4975](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4975)*
