[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [EFlipMode](_api_types_.eflipmode.md)

# Enumeration: EFlipMode

## Index

### Enumeration members

* [Extended](_api_types_.eflipmode.md#extended)
* [OFF](_api_types_.eflipmode.md#off)
* [ON](_api_types_.eflipmode.md#on)

## Enumeration members

###  Extended

• **Extended**: = "Extended"

*Defined in [api/types.ts:5269](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5269)*

___

###  OFF

• **OFF**: = "OFF"

*Defined in [api/types.ts:5261](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5261)*

___

###  ON

• **ON**: = "ON"

*Defined in [api/types.ts:5265](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5265)*
