[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PTZPresetTourDirection](_api_types_.ptzpresettourdirection.md)

# Enumeration: PTZPresetTourDirection

## Index

### Enumeration members

* [Backward](_api_types_.ptzpresettourdirection.md#backward)
* [Extended](_api_types_.ptzpresettourdirection.md#extended)
* [Forward](_api_types_.ptzpresettourdirection.md#forward)

## Enumeration members

###  Backward

• **Backward**: = "Backward"

*Defined in [api/types.ts:5327](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5327)*

___

###  Extended

• **Extended**: = "Extended"

*Defined in [api/types.ts:5331](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5331)*

___

###  Forward

• **Forward**: = "Forward"

*Defined in [api/types.ts:5323](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5323)*
