[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ScopeDefinition](_api_types_.scopedefinition.md)

# Enumeration: ScopeDefinition

## Index

### Enumeration members

* [Configurable](_api_types_.scopedefinition.md#configurable)
* [Fixed](_api_types_.scopedefinition.md#fixed)

## Enumeration members

###  Configurable

• **Configurable**: = "Configurable"

*Defined in [api/types.ts:4843](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4843)*

___

###  Fixed

• **Fixed**: = "Fixed"

*Defined in [api/types.ts:4839](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4839)*
