[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [Mpeg4Profile](_api_types_.mpeg4profile.md)

# Enumeration: Mpeg4Profile

## Index

### Enumeration members

* [ASP](_api_types_.mpeg4profile.md#asp)
* [SP](_api_types_.mpeg4profile.md#sp)

## Enumeration members

###  ASP

• **ASP**: = "ASP"

*Defined in [api/types.ts:4657](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4657)*

___

###  SP

• **SP**: = "SP"

*Defined in [api/types.ts:4653](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4653)*
