[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [RelayLogicalState](_api_types_.relaylogicalstate.md)

# Enumeration: RelayLogicalState

## Index

### Enumeration members

* [active](_api_types_.relaylogicalstate.md#active)
* [inactive](_api_types_.relaylogicalstate.md#inactive)

## Enumeration members

###  active

• **active**: = "active"

*Defined in [api/types.ts:5205](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5205)*

___

###  inactive

• **inactive**: = "inactive"

*Defined in [api/types.ts:5209](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5209)*
