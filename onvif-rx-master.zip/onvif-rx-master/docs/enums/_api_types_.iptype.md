[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [IPType](_api_types_.iptype.md)

# Enumeration: IPType

## Index

### Enumeration members

* [IPv4](_api_types_.iptype.md#ipv4)
* [IPv6](_api_types_.iptype.md#ipv6)

## Enumeration members

###  IPv4

• **IPv4**: = "IPv4"

*Defined in [api/types.ts:4939](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4939)*

___

###  IPv6

• **IPv6**: = "IPv6"

*Defined in [api/types.ts:4943](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4943)*
