[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [IrCutFilterAutoBoundaryType](_api_types_.ircutfilterautoboundarytype.md)

# Enumeration: IrCutFilterAutoBoundaryType

## Index

### Enumeration members

* [Common](_api_types_.ircutfilterautoboundarytype.md#common)
* [Extended](_api_types_.ircutfilterautoboundarytype.md#extended)
* [ToOff](_api_types_.ircutfilterautoboundarytype.md#tooff)
* [ToOn](_api_types_.ircutfilterautoboundarytype.md#toon)

## Enumeration members

###  Common

• **Common**: = "Common"

*Defined in [api/types.ts:5533](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5533)*

___

###  Extended

• **Extended**: = "Extended"

*Defined in [api/types.ts:5545](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5545)*

___

###  ToOff

• **ToOff**: = "ToOff"

*Defined in [api/types.ts:5541](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5541)*

___

###  ToOn

• **ToOn**: = "ToOn"

*Defined in [api/types.ts:5537](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5537)*
