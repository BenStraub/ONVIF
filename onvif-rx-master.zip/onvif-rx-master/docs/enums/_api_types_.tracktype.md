[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [TrackType](_api_types_.tracktype.md)

# Enumeration: TrackType

Placeholder for future extension.

## Index

### Enumeration members

* [Audio](_api_types_.tracktype.md#audio)
* [Extended](_api_types_.tracktype.md#extended)
* [Metadata](_api_types_.tracktype.md#metadata)
* [Video](_api_types_.tracktype.md#video)

## Enumeration members

###  Audio

• **Audio**: = "Audio"

*Defined in [api/types.ts:5749](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5749)*

___

###  Extended

• **Extended**: = "Extended"

*Defined in [api/types.ts:5757](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5757)*

Placeholder for future extension.

___

###  Metadata

• **Metadata**: = "Metadata"

*Defined in [api/types.ts:5753](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5753)*

___

###  Video

• **Video**: = "Video"

*Defined in [api/types.ts:5745](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5745)*
