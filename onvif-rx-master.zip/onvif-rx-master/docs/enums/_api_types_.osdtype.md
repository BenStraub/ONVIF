[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [OSDType](_api_types_.osdtype.md)

# Enumeration: OSDType

## Index

### Enumeration members

* [Extended](_api_types_.osdtype.md#extended)
* [Image](_api_types_.osdtype.md#image)
* [Text](_api_types_.osdtype.md#text)

## Enumeration members

###  Extended

• **Extended**: = "Extended"

*Defined in [api/types.ts:5818](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5818)*

___

###  Image

• **Image**: = "Image"

*Defined in [api/types.ts:5814](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5814)*

___

###  Text

• **Text**: = "Text"

*Defined in [api/types.ts:5810](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5810)*
