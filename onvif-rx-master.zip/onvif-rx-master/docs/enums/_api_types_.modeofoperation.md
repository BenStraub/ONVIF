[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ModeOfOperation](_api_types_.modeofoperation.md)

# Enumeration: ModeOfOperation

This case should never happen.

## Index

### Enumeration members

* [Active](_api_types_.modeofoperation.md#active)
* [Idle](_api_types_.modeofoperation.md#idle)
* [Unknown](_api_types_.modeofoperation.md#unknown)

## Enumeration members

###  Active

• **Active**: = "Active"

*Defined in [api/types.ts:5771](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5771)*

___

###  Idle

• **Idle**: = "Idle"

*Defined in [api/types.ts:5767](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5767)*

___

###  Unknown

• **Unknown**: = "Unknown"

*Defined in [api/types.ts:5775](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5775)*

This case should never happen.
