[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [Duplex](_api_types_.duplex.md)

# Enumeration: Duplex

## Index

### Enumeration members

* [Full](_api_types_.duplex.md#full)
* [Half](_api_types_.duplex.md#half)

## Enumeration members

###  Full

• **Full**: = "Full"

*Defined in [api/types.ts:4867](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4867)*

___

###  Half

• **Half**: = "Half"

*Defined in [api/types.ts:4871](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4871)*
