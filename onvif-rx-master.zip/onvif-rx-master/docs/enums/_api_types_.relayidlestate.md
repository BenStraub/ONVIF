[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [RelayIdleState](_api_types_.relayidlestate.md)

# Enumeration: RelayIdleState

## Index

### Enumeration members

* [closed](_api_types_.relayidlestate.md#closed)
* [open](_api_types_.relayidlestate.md#open)

## Enumeration members

###  closed

• **closed**: = "closed"

*Defined in [api/types.ts:5219](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5219)*

___

###  open

• **open**: = "open"

*Defined in [api/types.ts:5223](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5223)*
