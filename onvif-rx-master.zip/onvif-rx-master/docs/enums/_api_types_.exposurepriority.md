[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ExposurePriority](_api_types_.exposurepriority.md)

# Enumeration: ExposurePriority

## Index

### Enumeration members

* [FrameRate](_api_types_.exposurepriority.md#framerate)
* [LowNoise](_api_types_.exposurepriority.md#lownoise)

## Enumeration members

###  FrameRate

• **FrameRate**: = "FrameRate"

*Defined in [api/types.ts:5441](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5441)*

___

###  LowNoise

• **LowNoise**: = "LowNoise"

*Defined in [api/types.ts:5437](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5437)*
