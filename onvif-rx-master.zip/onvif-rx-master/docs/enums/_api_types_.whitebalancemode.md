[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [WhiteBalanceMode](_api_types_.whitebalancemode.md)

# Enumeration: WhiteBalanceMode

## Index

### Enumeration members

* [AUTO](_api_types_.whitebalancemode.md#auto)
* [MANUAL](_api_types_.whitebalancemode.md#manual)

## Enumeration members

###  AUTO

• **AUTO**: = "AUTO"

*Defined in [api/types.ts:5479](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5479)*

___

###  MANUAL

• **MANUAL**: = "MANUAL"

*Defined in [api/types.ts:5483](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5483)*
