[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [Dot11AuthAndMangementSuite](_api_types_.dot11authandmangementsuite.md)

# Enumeration: Dot11AuthAndMangementSuite

## Index

### Enumeration members

* [Dot1X](_api_types_.dot11authandmangementsuite.md#dot1x)
* [Extended](_api_types_.dot11authandmangementsuite.md#extended)
* [None](_api_types_.dot11authandmangementsuite.md#none)
* [PSK](_api_types_.dot11authandmangementsuite.md#psk)

## Enumeration members

###  Dot1X

• **Dot1X**: = "Dot1X"

*Defined in [api/types.ts:5085](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5085)*

___

###  Extended

• **Extended**: = "Extended"

*Defined in [api/types.ts:5093](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5093)*

___

###  None

• **None**: = "None"

*Defined in [api/types.ts:5081](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5081)*

___

###  PSK

• **PSK**: = "PSK"

*Defined in [api/types.ts:5089](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5089)*
