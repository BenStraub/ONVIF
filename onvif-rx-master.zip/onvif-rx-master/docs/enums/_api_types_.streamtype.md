[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [StreamType](_api_types_.streamtype.md)

# Enumeration: StreamType

## Index

### Enumeration members

* [RTP-Multicast](_api_types_.streamtype.md#rtp-multicast)
* [RTP-Unicast](_api_types_.streamtype.md#rtp-unicast)

## Enumeration members

###  RTP-Multicast

• **RTP-Multicast**: = "RTP-Multicast"

*Defined in [api/types.ts:4807](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4807)*

___

###  RTP-Unicast

• **RTP-Unicast**: = "RTP-Unicast"

*Defined in [api/types.ts:4803](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4803)*
