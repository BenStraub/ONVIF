[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [IPAddressFilterType](_api_types_.ipaddressfiltertype.md)

# Enumeration: IPAddressFilterType

## Index

### Enumeration members

* [Allow](_api_types_.ipaddressfiltertype.md#allow)
* [Deny](_api_types_.ipaddressfiltertype.md#deny)

## Enumeration members

###  Allow

• **Allow**: = "Allow"

*Defined in [api/types.ts:4953](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4953)*

___

###  Deny

• **Deny**: = "Deny"

*Defined in [api/types.ts:4957](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4957)*
