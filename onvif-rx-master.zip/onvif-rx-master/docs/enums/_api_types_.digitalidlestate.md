[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [DigitalIdleState](_api_types_.digitalidlestate.md)

# Enumeration: DigitalIdleState

## Index

### Enumeration members

* [closed](_api_types_.digitalidlestate.md#closed)
* [open](_api_types_.digitalidlestate.md#open)

## Enumeration members

###  closed

• **closed**: = "closed"

*Defined in [api/types.ts:5247](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5247)*

___

###  open

• **open**: = "open"

*Defined in [api/types.ts:5251](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5251)*
