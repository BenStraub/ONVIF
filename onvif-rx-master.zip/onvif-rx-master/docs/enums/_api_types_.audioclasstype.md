[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [AudioClassType](_api_types_.audioclasstype.md)

# Enumeration: AudioClassType

AudioClassType acceptable values are;
		   gun_shot, scream, glass_breaking, tire_screech

## Index

### Enumeration members

* [glass_breaking](_api_types_.audioclasstype.md#glass_breaking)
* [gun_shot](_api_types_.audioclasstype.md#gun_shot)
* [scream](_api_types_.audioclasstype.md#scream)
* [tire_screech](_api_types_.audioclasstype.md#tire_screech)

## Enumeration members

###  glass_breaking

• **glass_breaking**: = "glass_breaking"

*Defined in [api/types.ts:5796](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5796)*

___

###  gun_shot

• **gun_shot**: = "gun_shot"

*Defined in [api/types.ts:5788](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5788)*

___

###  scream

• **scream**: = "scream"

*Defined in [api/types.ts:5792](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5792)*

___

###  tire_screech

• **tire_screech**: = "tire_screech"

*Defined in [api/types.ts:5800](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5800)*
