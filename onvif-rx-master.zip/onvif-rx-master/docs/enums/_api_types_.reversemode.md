[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ReverseMode](_api_types_.reversemode.md)

# Enumeration: ReverseMode

## Index

### Enumeration members

* [AUTO](_api_types_.reversemode.md#auto)
* [Extended](_api_types_.reversemode.md#extended)
* [OFF](_api_types_.reversemode.md#off)
* [ON](_api_types_.reversemode.md#on)

## Enumeration members

###  AUTO

• **AUTO**: = "AUTO"

*Defined in [api/types.ts:5287](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5287)*

___

###  Extended

• **Extended**: = "Extended"

*Defined in [api/types.ts:5291](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5291)*

___

###  OFF

• **OFF**: = "OFF"

*Defined in [api/types.ts:5279](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5279)*

___

###  ON

• **ON**: = "ON"

*Defined in [api/types.ts:5283](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5283)*
