[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [WideDynamicMode](_api_types_.widedynamicmode.md)

# Enumeration: WideDynamicMode

## Index

### Enumeration members

* [OFF](_api_types_.widedynamicmode.md#off)
* [ON](_api_types_.widedynamicmode.md#on)

## Enumeration members

###  OFF

• **OFF**: = "OFF"

*Defined in [api/types.ts:5409](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5409)*

___

###  ON

• **ON**: = "ON"

*Defined in [api/types.ts:5413](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5413)*
