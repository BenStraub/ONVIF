[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [RelayMode](_api_types_.relaymode.md)

# Enumeration: RelayMode

## Index

### Enumeration members

* [Bistable](_api_types_.relaymode.md#bistable)
* [Monostable](_api_types_.relaymode.md#monostable)

## Enumeration members

###  Bistable

• **Bistable**: = "Bistable"

*Defined in [api/types.ts:5237](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5237)*

___

###  Monostable

• **Monostable**: = "Monostable"

*Defined in [api/types.ts:5233](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5233)*
