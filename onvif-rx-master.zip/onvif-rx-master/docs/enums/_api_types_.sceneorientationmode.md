[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [SceneOrientationMode](_api_types_.sceneorientationmode.md)

# Enumeration: SceneOrientationMode

## Index

### Enumeration members

* [AUTO](_api_types_.sceneorientationmode.md#auto)
* [MANUAL](_api_types_.sceneorientationmode.md#manual)

## Enumeration members

###  AUTO

• **AUTO**: = "AUTO"

*Defined in [api/types.ts:4567](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4567)*

___

###  MANUAL

• **MANUAL**: = "MANUAL"

*Defined in [api/types.ts:4563](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4563)*
