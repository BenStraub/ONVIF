[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [DefoggingMode](_api_types_.defoggingmode.md)

# Enumeration: DefoggingMode

## Index

### Enumeration members

* [AUTO](_api_types_.defoggingmode.md#auto)
* [OFF](_api_types_.defoggingmode.md#off)
* [ON](_api_types_.defoggingmode.md#on)

## Enumeration members

###  AUTO

• **AUTO**: = "AUTO"

*Defined in [api/types.ts:5581](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5581)*

___

###  OFF

• **OFF**: = "OFF"

*Defined in [api/types.ts:5573](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5573)*

___

###  ON

• **ON**: = "ON"

*Defined in [api/types.ts:5577](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5577)*
