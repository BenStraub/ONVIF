[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ToneCompensationMode](_api_types_.tonecompensationmode.md)

# Enumeration: ToneCompensationMode

## Index

### Enumeration members

* [AUTO](_api_types_.tonecompensationmode.md#auto)
* [OFF](_api_types_.tonecompensationmode.md#off)
* [ON](_api_types_.tonecompensationmode.md#on)

## Enumeration members

###  AUTO

• **AUTO**: = "AUTO"

*Defined in [api/types.ts:5563](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5563)*

___

###  OFF

• **OFF**: = "OFF"

*Defined in [api/types.ts:5555](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5555)*

___

###  ON

• **ON**: = "ON"

*Defined in [api/types.ts:5559](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5559)*
