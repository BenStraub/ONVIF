[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [ImageStabilizationMode](_api_types_.imagestabilizationmode.md)

# Enumeration: ImageStabilizationMode

## Index

### Enumeration members

* [AUTO](_api_types_.imagestabilizationmode.md#auto)
* [Extended](_api_types_.imagestabilizationmode.md#extended)
* [OFF](_api_types_.imagestabilizationmode.md#off)
* [ON](_api_types_.imagestabilizationmode.md#on)

## Enumeration members

###  AUTO

• **AUTO**: = "AUTO"

*Defined in [api/types.ts:5519](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5519)*

___

###  Extended

• **Extended**: = "Extended"

*Defined in [api/types.ts:5523](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5523)*

___

###  OFF

• **OFF**: = "OFF"

*Defined in [api/types.ts:5511](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5511)*

___

###  ON

• **ON**: = "ON"

*Defined in [api/types.ts:5515](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5515)*
