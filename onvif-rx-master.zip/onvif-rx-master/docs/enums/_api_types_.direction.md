[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [Direction](_api_types_.direction.md)

# Enumeration: Direction

## Index

### Enumeration members

* [Any](_api_types_.direction.md#any)
* [Left](_api_types_.direction.md#left)
* [Right](_api_types_.direction.md#right)

## Enumeration members

###  Any

• **Any**: = "Any"

*Defined in [api/types.ts:5635](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5635)*

___

###  Left

• **Left**: = "Left"

*Defined in [api/types.ts:5627](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5627)*

___

###  Right

• **Right**: = "Right"

*Defined in [api/types.ts:5631](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5631)*
