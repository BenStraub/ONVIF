[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PropertyOperation](_api_types_.propertyoperation.md)

# Enumeration: PropertyOperation

## Index

### Enumeration members

* [Changed](_api_types_.propertyoperation.md#changed)
* [Deleted](_api_types_.propertyoperation.md#deleted)
* [Initialized](_api_types_.propertyoperation.md#initialized)

## Enumeration members

###  Changed

• **Changed**: = "Changed"

*Defined in [api/types.ts:5617](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5617)*

___

###  Deleted

• **Deleted**: = "Deleted"

*Defined in [api/types.ts:5613](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5613)*

___

###  Initialized

• **Initialized**: = "Initialized"

*Defined in [api/types.ts:5609](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5609)*
