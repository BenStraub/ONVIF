[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [IrCutFilterMode](_api_types_.ircutfiltermode.md)

# Enumeration: IrCutFilterMode

## Index

### Enumeration members

* [AUTO](_api_types_.ircutfiltermode.md#auto)
* [OFF](_api_types_.ircutfiltermode.md#off)
* [ON](_api_types_.ircutfiltermode.md#on)

## Enumeration members

###  AUTO

• **AUTO**: = "AUTO"

*Defined in [api/types.ts:5501](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5501)*

___

###  OFF

• **OFF**: = "OFF"

*Defined in [api/types.ts:5497](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5497)*

___

###  ON

• **ON**: = "ON"

*Defined in [api/types.ts:5493](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5493)*
