[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [PTZPresetTourOperation](_api_types_.ptzpresettouroperation.md)

# Enumeration: PTZPresetTourOperation

## Index

### Enumeration members

* [Extended](_api_types_.ptzpresettouroperation.md#extended)
* [Pause](_api_types_.ptzpresettouroperation.md#pause)
* [Start](_api_types_.ptzpresettouroperation.md#start)
* [Stop](_api_types_.ptzpresettouroperation.md#stop)

## Enumeration members

###  Extended

• **Extended**: = "Extended"

*Defined in [api/types.ts:5353](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5353)*

___

###  Pause

• **Pause**: = "Pause"

*Defined in [api/types.ts:5349](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5349)*

___

###  Start

• **Start**: = "Start"

*Defined in [api/types.ts:5341](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5341)*

___

###  Stop

• **Stop**: = "Stop"

*Defined in [api/types.ts:5345](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5345)*
