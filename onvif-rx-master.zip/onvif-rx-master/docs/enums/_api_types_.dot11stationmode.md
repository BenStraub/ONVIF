[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [Dot11StationMode](_api_types_.dot11stationmode.md)

# Enumeration: Dot11StationMode

## Index

### Enumeration members

* [Ad-hoc](_api_types_.dot11stationmode.md#ad-hoc)
* [Extended](_api_types_.dot11stationmode.md#extended)
* [Infrastructure](_api_types_.dot11stationmode.md#infrastructure)

## Enumeration members

###  Ad-hoc

• **Ad-hoc**: = "Ad-hoc"

*Defined in [api/types.ts:4985](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4985)*

___

###  Extended

• **Extended**: = "Extended"

*Defined in [api/types.ts:4993](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4993)*

___

###  Infrastructure

• **Infrastructure**: = "Infrastructure"

*Defined in [api/types.ts:4989](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4989)*
