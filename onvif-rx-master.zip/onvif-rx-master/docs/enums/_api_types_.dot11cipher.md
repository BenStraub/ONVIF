[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [Dot11Cipher](_api_types_.dot11cipher.md)

# Enumeration: Dot11Cipher

## Index

### Enumeration members

* [Any](_api_types_.dot11cipher.md#any)
* [CCMP](_api_types_.dot11cipher.md#ccmp)
* [Extended](_api_types_.dot11cipher.md#extended)
* [TKIP](_api_types_.dot11cipher.md#tkip)

## Enumeration members

###  Any

• **Any**: = "Any"

*Defined in [api/types.ts:5037](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5037)*

___

###  CCMP

• **CCMP**: = "CCMP"

*Defined in [api/types.ts:5029](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5029)*

___

###  Extended

• **Extended**: = "Extended"

*Defined in [api/types.ts:5041](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5041)*

___

###  TKIP

• **TKIP**: = "TKIP"

*Defined in [api/types.ts:5033](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L5033)*
