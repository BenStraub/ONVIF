[onvif-rx](../README.md) › ["api/types"](../modules/_api_types_.md) › [TransportProtocol](_api_types_.transportprotocol.md)

# Enumeration: TransportProtocol

This value is deprecated.

## Index

### Enumeration members

* [HTTP](_api_types_.transportprotocol.md#http)
* [RTSP](_api_types_.transportprotocol.md#rtsp)
* [TCP](_api_types_.transportprotocol.md#tcp)
* [UDP](_api_types_.transportprotocol.md#udp)

## Enumeration members

###  HTTP

• **HTTP**: = "HTTP"

*Defined in [api/types.ts:4829](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4829)*

___

###  RTSP

• **RTSP**: = "RTSP"

*Defined in [api/types.ts:4825](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4825)*

___

###  TCP

• **TCP**: = "TCP"

*Defined in [api/types.ts:4821](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4821)*

This value is deprecated.

___

###  UDP

• **UDP**: = "UDP"

*Defined in [api/types.ts:4817](https://github.com/patrickmichalina/onvif-rx/blob/3e9b152/src/api/types.ts#L4817)*
