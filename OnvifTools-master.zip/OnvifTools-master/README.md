# OnvifTools
Python library for manage and automatification task of works onvif compatible ip cameras
## OnvifTools features
- supported user callback function
- supported work in daemon mode
- supported reaction on events
- supported native ptz-camera presets
#### coming soon features
- support ptz-control and create virtual ptz-tour
- support checking numbers of service ptz presets
- suport work in agent mode with the ability to connect to the server
