#include <VideoListener.h>

VideoListener::VideoListener() {
}

VideoListener::~VideoListener() {
}


