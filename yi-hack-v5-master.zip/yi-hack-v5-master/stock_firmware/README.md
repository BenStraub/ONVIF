# stock_firmware

Why an empty folder? Because I'm not sure if I can re-distribute on GitHub the original Xiaomi firmware images needed to create yi-hack-v5.

You can download the images from mega.nz (link coming soon)
