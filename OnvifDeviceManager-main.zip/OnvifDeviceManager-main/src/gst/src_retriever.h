#ifndef SRC_RETRIEVER_H_ 
#define SRC_RETRIEVER_H_

void
retrieve_audiosrc(char * element, char * device);

#endif