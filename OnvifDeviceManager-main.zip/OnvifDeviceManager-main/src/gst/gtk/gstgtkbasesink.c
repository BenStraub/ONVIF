/*
 * GStreamer
 * Copyright (C) 2015 Matthew Waters <matthew@centricular.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 51 Franklin St, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 */

/**
 * SECTION:gtkgstsink
 * @title: GstGtkBaseCustomSink
 *
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "gstgtkbasesink.h"
#include "gstgtkutils.h"
#include "gst/pbutils/gstpluginsbaseversion.h"

GST_DEBUG_CATEGORY (gst_debug_gtk_base_custom_sink);
#define GST_CAT_DEFAULT gst_debug_gtk_base_custom_sink

#define DEFAULT_FORCE_ASPECT_RATIO  TRUE
#define DEFAULT_DISPLAY_PAR_N       0
#define DEFAULT_DISPLAY_PAR_D       1
#define DEFAULT_VIDEO_PAR_N         0
#define DEFAULT_VIDEO_PAR_D         1
#define DEFAULT_IGNORE_ALPHA        TRUE

static void gst_gtk_base_custom_sink_finalize (GObject * object);
static void gst_gtk_base_custom_sink_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * param_spec);
static void gst_gtk_base_custom_sink_get_property (GObject * object, guint prop_id,
    GValue * value, GParamSpec * param_spec);

static gboolean gst_gtk_base_custom_sink_start (GstBaseSink * bsink);
static gboolean gst_gtk_base_custom_sink_stop (GstBaseSink * bsink);

static GstStateChangeReturn
gst_gtk_base_custom_sink_change_state (GstElement * element,
    GstStateChange transition);

static void gst_gtk_base_custom_sink_get_times (GstBaseSink * bsink, GstBuffer * buf,
    GstClockTime * start, GstClockTime * end);
static gboolean gst_gtk_base_custom_sink_set_caps (GstBaseSink * bsink,
    GstCaps * caps);
static GstFlowReturn gst_gtk_base_custom_sink_show_frame (GstVideoSink * bsink,
    GstBuffer * buf);

static void
gst_gtk_base_custom_sink_navigation_interface_init (GstNavigationInterface * iface);

static void gst_gtk_base_custom_sink_set_element_expand(GstGtkBaseCustomSink * bsink);

enum
{
  PROP_0,
  PROP_WIDGET,
  PROP_FORCE_ASPECT_RATIO,
  PROP_PIXEL_ASPECT_RATIO,
  PROP_VIDEO_ASPECT_RATIO_OVERRIDE,
  PROP_IGNORE_ALPHA,
};

#define gst_gtk_base_custom_sink_parent_class parent_class
G_DEFINE_ABSTRACT_TYPE_WITH_CODE (GstGtkBaseCustomSink, gst_gtk_base_custom_sink,
    GST_TYPE_VIDEO_SINK,
    G_IMPLEMENT_INTERFACE (GST_TYPE_NAVIGATION,
        gst_gtk_base_custom_sink_navigation_interface_init)
    GST_DEBUG_CATEGORY_INIT (gst_debug_gtk_base_custom_sink,
        "gtkbasecustomsink", 0, "Gtk Video Sink base class"))


static void
gst_gtk_base_custom_sink_class_init (GstGtkBaseCustomSinkClass * klass)
{
  GObjectClass *gobject_class;
  GstElementClass *gstelement_class;
  GstBaseSinkClass *gstbasesink_class;
  GstVideoSinkClass *gstvideosink_class;

  gobject_class = (GObjectClass *) klass;
  gstelement_class = (GstElementClass *) klass;
  gstbasesink_class = (GstBaseSinkClass *) klass;
  gstvideosink_class = (GstVideoSinkClass *) klass;

  gobject_class->set_property = gst_gtk_base_custom_sink_set_property;
  gobject_class->get_property = gst_gtk_base_custom_sink_get_property;

  g_object_class_install_property (gobject_class, PROP_WIDGET,
      g_param_spec_object ("widget", "Gtk Widget",
          "The GtkWidget to place in the widget hierarchy "
          "(must only be get from the GTK main thread)",
          GTK_TYPE_WIDGET,
          G_PARAM_READABLE | G_PARAM_STATIC_STRINGS |
          GST_PARAM_DOC_SHOW_DEFAULT));

  g_object_class_install_property (gobject_class, PROP_FORCE_ASPECT_RATIO,
      g_param_spec_boolean ("force-aspect-ratio",
          "Force aspect ratio",
          "When enabled, scaling will respect original aspect ratio",
          DEFAULT_FORCE_ASPECT_RATIO,
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  g_object_class_install_property (gobject_class, PROP_PIXEL_ASPECT_RATIO,
      gst_param_spec_fraction ("pixel-aspect-ratio", "Pixel Aspect Ratio",
          "The pixel aspect ratio of the device",
          0, G_MAXINT, G_MAXINT, 1, DEFAULT_DISPLAY_PAR_N,
          DEFAULT_DISPLAY_PAR_D, G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  /**
   * GstGtkBaseCustomSink:video-aspect-ratio-override:
   *
   * The pixel aspect ratio of the video (0/1 = follow stream)
   *
   * Since: 1.20
   */
  g_object_class_install_property (gobject_class,
      PROP_VIDEO_ASPECT_RATIO_OVERRIDE,
      gst_param_spec_fraction ("video-aspect-ratio-override",
          "Video Pixel Aspect Ratio",
          "The pixel aspect ratio of the video (0/1 = follow stream)", 0,
          G_MAXINT, G_MAXINT, 1, DEFAULT_VIDEO_PAR_N, DEFAULT_VIDEO_PAR_D,
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  g_object_class_install_property (gobject_class, PROP_IGNORE_ALPHA,
      g_param_spec_boolean ("ignore-alpha", "Ignore Alpha",
          "When enabled, alpha will be ignored and converted to black",
          DEFAULT_IGNORE_ALPHA, G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  gobject_class->finalize = gst_gtk_base_custom_sink_finalize;

  gstelement_class->change_state = gst_gtk_base_custom_sink_change_state;
  gstbasesink_class->set_caps = gst_gtk_base_custom_sink_set_caps;
  gstbasesink_class->get_times = gst_gtk_base_custom_sink_get_times;
  gstbasesink_class->start = gst_gtk_base_custom_sink_start;
  gstbasesink_class->stop = gst_gtk_base_custom_sink_stop;

  gstvideosink_class->show_frame = gst_gtk_base_custom_sink_show_frame;

  gst_type_mark_as_plugin_api (GST_TYPE_GTK_BASE_CUSTOM_SINK, 0);
}

static void
gst_gtk_base_custom_sink_init (GstGtkBaseCustomSink * gtk_sink)
{
  gtk_sink->force_aspect_ratio = DEFAULT_FORCE_ASPECT_RATIO;
  gtk_sink->par_n = DEFAULT_DISPLAY_PAR_N;
  gtk_sink->par_d = DEFAULT_DISPLAY_PAR_D;
  gtk_sink->video_par_n = DEFAULT_VIDEO_PAR_N;
  gtk_sink->video_par_d = DEFAULT_VIDEO_PAR_D;
  gtk_sink->ignore_alpha = DEFAULT_IGNORE_ALPHA;
  gtk_sink->expand = FALSE;
}

static void
gst_gtk_base_custom_sink_finalize (GObject * object)
{
  GstGtkBaseCustomSink *gtk_sink = GST_GTK_BASE_CUSTOM_SINK (object);
  GST_OBJECT_LOCK (gtk_sink);
  if (gtk_sink->window && gtk_sink->window_destroy_id)
    g_signal_handler_disconnect (gtk_sink->window, gtk_sink->window_destroy_id);
  if (gtk_sink->widget && gtk_sink->widget_destroy_id)
    g_signal_handler_disconnect (gtk_sink->widget, gtk_sink->widget_destroy_id);

  g_clear_object (&gtk_sink->widget);
  GST_OBJECT_UNLOCK (gtk_sink);

  G_OBJECT_CLASS (parent_class)->finalize (object);
}

static void
widget_destroy_cb (GtkWidget * widget, GstGtkBaseCustomSink * gtk_sink)
{
  GST_OBJECT_LOCK (gtk_sink);
  g_clear_object (&gtk_sink->widget);
  GST_OBJECT_UNLOCK (gtk_sink);
}

// static void
// window_destroy_cb (GtkWidget * widget, GstGtkBaseCustomSink * gtk_sink)
// {
//   GST_OBJECT_LOCK (gtk_sink);
//   gtk_sink->window = NULL;
//   GST_OBJECT_UNLOCK (gtk_sink);
// }

GtkGstBaseCustomWidget *
gst_gtk_base_custom_sink_set_widget (GstGtkBaseCustomSink * gtk_sink,GtkGstBaseCustomWidget * widget)
{
  if (gtk_sink->widget != NULL)
    g_object_unref (gtk_sink->widget);

  /* Ensure GTK is initialized, this has no side effect if it was already
  * initialized. Also, we do that lazily, so the application can be first */
  if (!gtk_init_check (NULL, NULL)) {
    GST_INFO_OBJECT (gtk_sink, "Could not ensure GTK initialization.");
    return NULL;
  }

  GST_OBJECT_LOCK (gtk_sink);
  gtk_sink->widget = widget;
  GST_OBJECT_UNLOCK (gtk_sink);

  return widget;
}

GtkGstBaseCustomWidget *
gst_gtk_base_custom_sink_get_widget (GstGtkBaseCustomSink * gtk_sink)
{
  if (gtk_sink->widget != NULL)
    return g_object_ref (gtk_sink->widget);

  /* Ensure GTK is initialized, this has no side effect if it was already
   * initialized. Also, we do that lazily, so the application can be first */
  if (!gtk_init_check (NULL, NULL)) {
    GST_INFO_OBJECT (gtk_sink, "Could not ensure GTK initialization.");
    return NULL;
  }

  g_assert (GST_GTK_BASE_CUSTOM_SINK_GET_CLASS (gtk_sink)->create_widget);
  gtk_sink->widget = (GtkGstBaseCustomWidget *)
      GST_GTK_BASE_CUSTOM_SINK_GET_CLASS (gtk_sink)->create_widget ();

  gtk_sink->bind_aspect_ratio =
      g_object_bind_property (gtk_sink, "force-aspect-ratio", gtk_sink->widget,
      "force-aspect-ratio", G_BINDING_BIDIRECTIONAL | G_BINDING_SYNC_CREATE);
  gtk_sink->bind_pixel_aspect_ratio =
      g_object_bind_property (gtk_sink, "pixel-aspect-ratio", gtk_sink->widget,
      "pixel-aspect-ratio", G_BINDING_BIDIRECTIONAL | G_BINDING_SYNC_CREATE);
  gtk_sink->bind_video_aspect_ratio =
      g_object_bind_property (gtk_sink, "video-aspect-ratio-override",
      gtk_sink->widget, "video-aspect-ratio-override",
      G_BINDING_BIDIRECTIONAL | G_BINDING_SYNC_CREATE);
  gtk_sink->bind_ignore_alpha =
      g_object_bind_property (gtk_sink, "ignore-alpha", gtk_sink->widget,
      "ignore-alpha", G_BINDING_BIDIRECTIONAL | G_BINDING_SYNC_CREATE);

  /* Take the floating ref, other wise the destruction of the container will
   * make this widget disappear possibly before we are done. */
  gst_object_ref_sink (gtk_sink->widget);
  gtk_sink->widget_destroy_id = g_signal_connect (gtk_sink->widget, "destroy",
      G_CALLBACK (widget_destroy_cb), gtk_sink);

  /* back pointer */
  gtk_gst_base_custom_widget_set_element (GTK_GST_BASE_CUSTOM_WIDGET (gtk_sink->widget),
      GST_ELEMENT (gtk_sink));

  return gtk_sink->widget;
}
void
gst_gtk_base_custom_sink_set_parent (GstGtkBaseCustomSink * gtk_sink, GtkWidget * parent){
  GST_OBJECT_LOCK (gtk_sink);
  gtk_sink->widget_parent = parent;
  GST_OBJECT_UNLOCK (gtk_sink);
}

GtkWidget *
gst_gtk_base_custom_sink_acquire_widget (GstGtkBaseCustomSink * gtk_sink)
{
  gpointer widget = NULL;

  GST_OBJECT_LOCK (gtk_sink);
  if (gtk_sink->widget != NULL)
    widget = g_object_ref (gtk_sink->widget);
  GST_OBJECT_UNLOCK (gtk_sink);

  if (!widget)
    widget =
        gst_gtk_custom_invoke_on_main ((GThreadFunc) gst_gtk_base_custom_sink_get_widget,
        gtk_sink);

  return widget;
}

static void
gst_gtk_base_custom_sink_get_property (GObject * object, guint prop_id,
    GValue * value, GParamSpec * pspec)
{
  GstGtkBaseCustomSink *gtk_sink = GST_GTK_BASE_CUSTOM_SINK (object);

  switch (prop_id) {
    case PROP_WIDGET:
    {
      g_value_take_object (value, gst_gtk_base_custom_sink_acquire_widget (gtk_sink));
      break;
    }
    case PROP_FORCE_ASPECT_RATIO:
      g_value_set_boolean (value, gtk_sink->force_aspect_ratio);
      break;
    case PROP_PIXEL_ASPECT_RATIO:
      gst_value_set_fraction (value, gtk_sink->par_n, gtk_sink->par_d);
      break;
    case PROP_VIDEO_ASPECT_RATIO_OVERRIDE:
      gst_value_set_fraction (value, gtk_sink->video_par_n,
          gtk_sink->video_par_d);
      break;
    case PROP_IGNORE_ALPHA:
      g_value_set_boolean (value, gtk_sink->ignore_alpha);
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }
}

static void
gst_gtk_base_custom_sink_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * pspec)
{
  GstGtkBaseCustomSink *gtk_sink = GST_GTK_BASE_CUSTOM_SINK (object);

  switch (prop_id) {
    case PROP_FORCE_ASPECT_RATIO:
      gtk_sink->force_aspect_ratio = g_value_get_boolean (value);
      break;
    case PROP_PIXEL_ASPECT_RATIO:
      gtk_sink->par_n = gst_value_get_fraction_numerator (value);
      gtk_sink->par_d = gst_value_get_fraction_denominator (value);
      break;
    case PROP_VIDEO_ASPECT_RATIO_OVERRIDE:
      gtk_sink->video_par_n = gst_value_get_fraction_numerator (value);
      gtk_sink->video_par_d = gst_value_get_fraction_denominator (value);
      break;
    case PROP_IGNORE_ALPHA:
      gtk_sink->ignore_alpha = g_value_get_boolean (value);
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }
}
#if (GST_PLUGINS_BASE_VERSION_MAJOR >= 1) && (GST_PLUGINS_BASE_VERSION_MINOR >= 21)
static void
gst_gtk_base_custom_sink_navigation_send_event (GstNavigation * navigation,
    GstEvent * event)
{
  GstGtkBaseCustomSink *sink = GST_GTK_BASE_CUSTOM_SINK (navigation);
  GstPad *pad;
  gdouble x, y;
  event = gst_event_make_writable (event);

  if (gst_navigation_event_get_coordinates (event, &x, &y)) {
    GtkGstBaseCustomWidget *widget = gst_gtk_base_custom_sink_get_widget (sink);
    gdouble stream_x, stream_y;

    if (widget == NULL) {
      GST_ERROR_OBJECT (sink, "Could not ensure GTK initialization.");
      return;
    }

    gtk_gst_base_custom_widget_display_size_to_stream_size (widget,
        x, y, &stream_x, &stream_y);
    gst_navigation_event_set_coordinates (event, stream_x, stream_y);
  }

  pad = gst_pad_get_peer (GST_VIDEO_SINK_PAD (sink));

  GST_TRACE_OBJECT (sink, "navigation event %" GST_PTR_FORMAT,
      (void *)gst_event_get_structure (event));

  if (GST_IS_PAD (pad) && GST_IS_EVENT (event)) {
    if (!gst_pad_send_event (pad, gst_event_ref (event))) {
      /* If upstream didn't handle the event we'll post a message with it
       * for the application in case it wants to do something with it */
      gst_element_post_message (GST_ELEMENT_CAST (sink),
          gst_navigation_message_new_event (GST_OBJECT_CAST (sink), event));
    }
    gst_event_unref (event);
    gst_object_unref (pad);
  }
}
#endif
static void
gst_gtk_base_custom_sink_navigation_interface_init (GstNavigationInterface * iface)
{
#if (GST_PLUGINS_BASE_VERSION_MAJOR >= 1) && (GST_PLUGINS_BASE_VERSION_MINOR >= 21)
  iface->send_event_simple = gst_gtk_base_custom_sink_navigation_send_event;
#endif
}

static void * gst_gtk_base_custom_sink_start_on_main (void * data)
{
  GstBaseSink * bsink = (GstBaseSink *) data;
  GstGtkBaseCustomSink *gst_sink = GST_GTK_BASE_CUSTOM_SINK (bsink);
  // GstGtkBaseCustomSinkClass *klass = GST_GTK_BASE_CUSTOM_SINK_GET_CLASS (bsink);
  GtkWidget *toplevel;

  if (gst_gtk_base_custom_sink_get_widget (gst_sink) == NULL) {
    GST_ERROR_OBJECT (bsink, "Could not ensure GTK initialization.");
    return FALSE;
  }

  /* After this point, gtk_sink->widget will always be set */

  toplevel = gtk_widget_get_toplevel (GTK_WIDGET (gst_sink->widget));
  if (!gtk_widget_is_toplevel (toplevel)) {
    // gtk_grid_attach (GTK_GRID (gst_sink->widget_parent), GTK_WIDGET(gst_sink->widget), 0, 1, 1, 1);
    gst_gtk_base_custom_sink_set_element_expand(gst_sink);
    gtk_container_add (GTK_CONTAINER (gst_sink->widget_parent), GTK_WIDGET(gst_sink->widget));
    gtk_widget_show(GTK_WIDGET(gst_sink->widget));
  //   /* sanity check */
  //   g_assert (klass->window_title);

  //   /* User did not add widget its own UI, let's popup a new GtkWindow to
  //    * make gst-launch-1.0 work. */
  //   gst_sink->window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  //   gtk_window_set_default_size (GTK_WINDOW (gst_sink->window), 640, 480);
  //   gtk_window_set_title (GTK_WINDOW (gst_sink->window), klass->window_title);
  //   gtk_container_add (GTK_CONTAINER (gst_sink->window), toplevel);
  //   gst_sink->window_destroy_id = g_signal_connect (gst_sink->window, "destroy",
  //       G_CALLBACK (window_destroy_cb), gst_sink);
  }

  return (void*) TRUE;
}

static void gst_gtk_base_custom_sink_set_element_expand(GstGtkBaseCustomSink * bsink){
  if(bsink->widget){
    gtk_widget_set_vexpand(GTK_WIDGET(bsink->widget),bsink->expand);
    gtk_widget_set_hexpand(GTK_WIDGET(bsink->widget),bsink->expand);
  }
}

void gst_gtk_base_custom_sink_set_expand(GstGtkBaseCustomSink * bsink, gboolean val){
  bsink->expand = val;
  gst_gtk_base_custom_sink_set_element_expand(bsink);
}

static gboolean
gst_gtk_base_custom_sink_start (GstBaseSink * bsink)
{
  return ! !gst_gtk_custom_invoke_on_main ((GThreadFunc)
      gst_gtk_base_custom_sink_start_on_main, bsink);
}

void * gst_gtk_base_custom_sink_stop_on_main (void * data)
{
  GstBaseSink * bsink = (GstBaseSink *) data;
  GstGtkBaseCustomSink *gst_sink = GST_GTK_BASE_CUSTOM_SINK (bsink);
  if (gst_sink->window) {
    gtk_widget_destroy (gst_sink->window);
    gst_sink->window = NULL;
    gst_sink->widget = NULL;
  }

  return (void*)TRUE;
}

static gboolean
gst_gtk_base_custom_sink_stop (GstBaseSink * bsink)
{
  GstGtkBaseCustomSink *gst_sink = GST_GTK_BASE_CUSTOM_SINK (bsink);

  if (gst_sink->window)
    return ! !gst_gtk_custom_invoke_on_main ((GThreadFunc)
        gst_gtk_base_custom_sink_stop_on_main, bsink);

  return TRUE;
}

static void *
gst_gtk_widget_show_all_and_unref (void * data)
{
  GtkWidget * widget = (GtkWidget *) data;
  gtk_widget_show_all (widget);
  g_object_unref (widget);
  return NULL;
}

static GstStateChangeReturn
gst_gtk_base_custom_sink_change_state (GstElement * element, GstStateChange transition)
{
  GstGtkBaseCustomSink *gtk_sink = GST_GTK_BASE_CUSTOM_SINK (element);
  GstStateChangeReturn ret = GST_STATE_CHANGE_SUCCESS;
  GST_DEBUG_OBJECT (element, "changing state: %s => %s",
      gst_element_state_get_name (GST_STATE_TRANSITION_CURRENT (transition)),
      gst_element_state_get_name (GST_STATE_TRANSITION_NEXT (transition)));

  ret = GST_ELEMENT_CLASS (parent_class)->change_state (element, transition);
  if (ret == GST_STATE_CHANGE_FAILURE)
    return ret;

  switch (transition) {
    case GST_STATE_CHANGE_READY_TO_PAUSED:
    {
      GtkWindow *window = NULL;

      GST_OBJECT_LOCK (gtk_sink);
      if (gtk_sink->window)
        window = g_object_ref (GTK_WINDOW (gtk_sink->window));
      GST_OBJECT_UNLOCK (gtk_sink);

      if (window)
        gst_gtk_custom_invoke_on_main ((GThreadFunc) gst_gtk_widget_show_all_and_unref,
            window);

      break;
    }
    case GST_STATE_CHANGE_PAUSED_TO_READY:
      GST_OBJECT_LOCK (gtk_sink);
      if (gtk_sink->widget)
        gtk_gst_base_custom_widget_set_buffer (gtk_sink->widget, NULL);
      GST_OBJECT_UNLOCK (gtk_sink);
      break;
    default:
      break;
  }

  return ret;
}

static void
gst_gtk_base_custom_sink_get_times (GstBaseSink * bsink, GstBuffer * buf,
    GstClockTime * start, GstClockTime * end)
{
  GstGtkBaseCustomSink *gtk_sink;
  gtk_sink = GST_GTK_BASE_CUSTOM_SINK (bsink);

  if (GST_BUFFER_TIMESTAMP_IS_VALID (buf)) {
    *start = GST_BUFFER_TIMESTAMP (buf);
    if (GST_BUFFER_DURATION_IS_VALID (buf))
      *end = *start + GST_BUFFER_DURATION (buf);
    else {
      if (GST_VIDEO_INFO_FPS_N (&gtk_sink->v_info) > 0) {
        *end = *start +
            gst_util_uint64_scale_int (GST_SECOND,
            GST_VIDEO_INFO_FPS_D (&gtk_sink->v_info),
            GST_VIDEO_INFO_FPS_N (&gtk_sink->v_info));
      }
    }
  }
}

gboolean
gst_gtk_base_custom_sink_set_caps (GstBaseSink * bsink, GstCaps * caps)
{
  GstGtkBaseCustomSink *gtk_sink = GST_GTK_BASE_CUSTOM_SINK (bsink);
  GST_DEBUG ("set caps with %" GST_PTR_FORMAT, (void *) caps);

  if (!gst_video_info_from_caps (&gtk_sink->v_info, caps))
    return FALSE;

  GST_OBJECT_LOCK (gtk_sink);

  if (gtk_sink->widget == NULL) {
    GST_OBJECT_UNLOCK (gtk_sink);
    GST_ELEMENT_ERROR (gtk_sink, RESOURCE, NOT_FOUND,
        ("%s", "Output widget was destroyed"), (NULL));
    return FALSE;
  }

  if (!gtk_gst_base_custom_widget_set_format (gtk_sink->widget, &gtk_sink->v_info)) {
    GST_OBJECT_UNLOCK (gtk_sink);
    return FALSE;
  }
  GST_OBJECT_UNLOCK (gtk_sink);

  return TRUE;
}

static GstFlowReturn
gst_gtk_base_custom_sink_show_frame (GstVideoSink * vsink, GstBuffer * buf)
{
  GstGtkBaseCustomSink *gtk_sink;
  GST_TRACE ("rendering buffer:%p", (void *) buf);

  gtk_sink = GST_GTK_BASE_CUSTOM_SINK (vsink);

  GST_OBJECT_LOCK (vsink);

  if (gtk_sink->widget == NULL) {
    GST_OBJECT_UNLOCK (gtk_sink);
    GST_ELEMENT_ERROR (gtk_sink, RESOURCE, NOT_FOUND,
        ("%s", "Output widget was destroyed"), (NULL));
    return GST_FLOW_ERROR;
  }

  gtk_gst_base_custom_widget_set_buffer (gtk_sink->widget, buf);

  GST_OBJECT_UNLOCK (gtk_sink);

  return GST_FLOW_OK;
}
