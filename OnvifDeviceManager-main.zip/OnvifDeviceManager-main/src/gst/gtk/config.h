#pragma once


#define GST_LICENSE "LGPL"

#define GST_PACKAGE_NAME "GStreamer Custom Plugin"

#define GST_PACKAGE_ORIGIN "Unknown package origin"