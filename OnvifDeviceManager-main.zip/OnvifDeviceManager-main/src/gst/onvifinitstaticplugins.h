#ifndef ONVIF_STATIC_PLUGINS_H_ 
#define ONVIF_STATIC_PLUGINS_H_

void
onvif_init_static_plugins (void);

#endif