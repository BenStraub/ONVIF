#ifndef DOTTED_SLIDDER_H_ 
#define DOTTED_SLIDDER_H_

#include <gtk/gtk.h>

GtkWidget * create_dotted_slider_animation(double item_count, double animation_time);

#endif