#ifndef GTK_DOTTED_SLIDDER_H_ 
#define GTK_DOTTED_SLIDDER_H_

#include <gtk/gtk.h>

GtkWidget * css_dotted_slider_animation_new(int item_count, unsigned int animation_time);

#endif