#ifndef ONVIF_APP_SHUTDOWN_H_ 
#define ONVIF_APP_SHUTDOWN_H_

#include "onvif_app.h"

void onvif_app_shutdown(OnvifApp * self);

#endif