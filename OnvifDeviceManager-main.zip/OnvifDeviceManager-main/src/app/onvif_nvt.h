#ifndef ONVIF_NVT_H_ 
#define ONVIF_NVT_H_

#include "../gst/gstrtspplayer.h"

GtkWidget * OnvifNVT__create_ui (GstRtspPlayer * player);

#endif