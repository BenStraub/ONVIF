If your system does not installed the VS2019 redistributable package, please download and install it.

VS2019 x86 redistributable package:
https://www.happytimesoft.com/downloads/vs2019-vcredist_x86.exe

VS2019 x64 redistributable package:
https://www.happytimesoft.com/downloads/vs2019-vcredist_x64.exe
