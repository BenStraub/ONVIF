# This repo is forked from Happy RTSP server and used to simulate ONVIF Camera for test operations.
