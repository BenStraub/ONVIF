from django.apps import AppConfig


class CameraConfig(AppConfig):
    name = 'camera'
