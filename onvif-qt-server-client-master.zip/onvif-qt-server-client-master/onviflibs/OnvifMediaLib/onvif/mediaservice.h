#ifndef MEDIASERVICE_H
#define MEDIASERVICE_H
#include "onvif/mediaserviceextabst.h"

class MediaService
{
public:
    MediaService(){

    };
    static MediaServiceExtAbst *serviceExt;
};

#endif // MEDIASERVICE_H
