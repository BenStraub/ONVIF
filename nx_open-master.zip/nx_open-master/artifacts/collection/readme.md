File `src/collection.h` is derived from ArXLib with the permission of its owner:
Alexander Fokin <apfokin@gmail.com>.
See https://github.com/elrinor/arxlib/ (former http://code.google.com/p/arxlib/)
