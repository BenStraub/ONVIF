This directory contains a header-only extension of `boost.preprocessor` library, needed for the
implementation of `nx_fusion` library (via including `variadic_seq_for_each.h`).

The original code, as well as this derivative work, is licensed under the terms of
Boost Software License, Version 1.0 (http://www.boost.org/LICENSE_1_0.txt,
stored for convenience in this repository in `licenses/license_boost_1_0.txt`).
