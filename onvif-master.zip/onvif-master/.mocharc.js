module.exports = {
    'spec': 'test/*.js',
    'exclude': 'test/serverMockup.js'
};
