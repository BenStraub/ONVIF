# Contribution Guidelines

## Add new method
I've tried to explain the easiest the best way to do it in this comment for the issue: https://github.com/agsh/onvif/issues/250#issuecomment-1273208097
