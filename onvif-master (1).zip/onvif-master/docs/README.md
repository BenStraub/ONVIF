some specs

+ [ONVIF-Core-Specification -2019](./ONVIF-Core-Specification.pdf)
