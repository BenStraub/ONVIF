//Package onvif is developed to provide an ONVIF client implementation on Go programming language
package onvif
