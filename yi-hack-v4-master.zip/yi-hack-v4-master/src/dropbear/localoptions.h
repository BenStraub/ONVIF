#ifndef DROPBEAR_LOCALOPTIONS_H
#define DROPBEAR_LOCALOPTIONS_H

#define DSS_PRIV_FILENAME "/home/yi-hack-v4/etc/dropbear/dropbear_dss_host_key"
#define RSA_PRIV_FILENAME "/home/yi-hack-v4/etc/dropbear/dropbear_rsa_host_key"
#define ECDSA_PRIV_FILENAME "/home/yi-hack-v4/etc/dropbear/dropbear_ecdsa_host_key"

#endif /* DROPBEAR_LOCALOPTIONS_H */
